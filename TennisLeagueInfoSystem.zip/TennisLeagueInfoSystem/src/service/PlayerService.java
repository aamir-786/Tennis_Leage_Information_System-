package service;

import model.Player;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PlayerService {
    private Connection connect() throws SQLException {
        return DriverManager.getConnection("jdbc:mysql://localhost:3306/tennis_league", "root", "Sh1@3+5");
    }

    public void addPlayer(Player player) throws SQLException {
        String sql = "INSERT INTO players (name, team_id) VALUES (?, ?)";
        try (Connection conn = connect(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, player.getName());
            stmt.setInt(2, player.getTeamId());
            stmt.executeUpdate();
        }
    }

    public void updatePlayer(Player player) throws SQLException {
        String sql = "UPDATE players SET name = ?, team_id = ? WHERE id = ?";
        try (Connection conn = connect(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, player.getName());
            stmt.setInt(2, player.getTeamId());
            stmt.setInt(3, player.getId());
            stmt.executeUpdate();
        }
    }

    public void deletePlayer(int id) throws SQLException {
        String sql = "DELETE FROM players WHERE id = ?";
        try (Connection conn = connect(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }

    public List<Player> getAllPlayers() throws SQLException {
        List<Player> players = new ArrayList<>();
        String sql = "SELECT * FROM players";
        try (Connection conn = connect(); Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Player player = new Player();
                player.setId(rs.getInt("id"));
                player.setName(rs.getString("name"));
                player.setTeamId(rs.getInt("team_id"));
                players.add(player);
            }
        }
        return players;
    }

    public Player getPlayerById(int id) throws SQLException {
        String sql = "SELECT * FROM players WHERE id = ?";
        try (Connection conn = connect(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Player player = new Player();
                    player.setId(rs.getInt("id"));
                    player.setName(rs.getString("name"));
                    player.setTeamId(rs.getInt("team_id"));
                    return player;
                }
            }
        }
        return null;
    }
}
