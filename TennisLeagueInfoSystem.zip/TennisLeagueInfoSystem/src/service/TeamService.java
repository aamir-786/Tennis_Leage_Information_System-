package service;

import model.Team;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TeamService {
    private Connection connect() throws SQLException {
        return DriverManager.getConnection("jdbc:mysql://localhost:3306/tennis_league", "root", "Sh1@3+5");
    }

    public void addTeam(Team team) throws SQLException {
        String sql = "INSERT INTO teams (name, coach_id) VALUES (?, ?)";
        try (Connection conn = connect(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, team.getName());
            stmt.setInt(2, team.getCoachId());
            stmt.executeUpdate();
        }
    }

    public void updateTeam(Team team) throws SQLException {
        String sql = "UPDATE teams SET name = ?, coach_id = ? WHERE id = ?";
        try (Connection conn = connect(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, team.getName());
            stmt.setInt(2, team.getCoachId());
            stmt.setInt(3, team.getId());
            stmt.executeUpdate();
        }
    }

    public void deleteTeam(int id) throws SQLException {
        String sql = "DELETE FROM teams WHERE id = ?";
        try (Connection conn = connect(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }

    public List<Team> getAllTeams() throws SQLException {
        List<Team> teams = new ArrayList<>();
        String sql = "SELECT * FROM teams";
        try (Connection conn = connect(); Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Team team = new Team();
                team.setId(rs.getInt("id"));
                team.setName(rs.getString("name"));
                team.setCoachId(rs.getInt("coach_id"));
                teams.add(team);
            }
        }
        return teams;
    }

    public Team getTeamById(int id) throws SQLException {
        String sql = "SELECT * FROM teams WHERE id = ?";
        try (Connection conn = connect(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Team team = new Team();
                    team.setId(rs.getInt("id"));
                    team.setName(rs.getString("name"));
                    team.setCoachId(rs.getInt("coach_id"));
                    return team;
                }
            }
        }
        return null;
    }
}
