package service;

import database.DatabaseConnection;
import model.Coach;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CoachService {
    private Connection connection;

    public CoachService() throws SQLException {
        // Initialize the database connection
        connection = DatabaseConnection.getConnection();
    }

    public Coach getCoachById(int id) throws SQLException {
        String query = "SELECT * FROM coaches WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, id);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    Coach coach = new Coach();
                    coach.setId(resultSet.getInt("id"));
                    coach.setName(resultSet.getString("name"));
                    coach.setTeamId(resultSet.getInt("team_id"));
                    return coach;
                }
            }
        }
        return null;
    }

    public List<Coach> getAllCoaches() throws SQLException {
        List<Coach> coaches = new ArrayList<>();
        String query = "SELECT * FROM coaches";
        try (PreparedStatement statement = connection.prepareStatement(query);
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                Coach coach = new Coach();
                coach.setId(resultSet.getInt("id"));
                coach.setName(resultSet.getString("name"));
                coach.setTeamId(resultSet.getInt("team_id"));
                coaches.add(coach);
            }
        }
        return coaches;
    }

    public void addCoach(Coach coach) throws SQLException {
        String query = "INSERT INTO coaches (name, team_id) VALUES (?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, coach.getName());
            statement.setInt(2, coach.getTeamId());
            statement.executeUpdate();
        }
    }

    public void updateCoach(Coach coach) throws SQLException {
        String query = "UPDATE coaches SET name = ?, team_id = ? WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, coach.getName());
            statement.setInt(2, coach.getTeamId());
            statement.setInt(3, coach.getId());
            statement.executeUpdate();
        }
    }

    public void deleteCoach(int id) throws SQLException {
        String query = "DELETE FROM coaches WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, id);
            statement.executeUpdate();
        }
    }
}
