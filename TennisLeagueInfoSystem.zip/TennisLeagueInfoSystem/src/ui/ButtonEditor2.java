package ui;

import javax.swing.*;
import java.awt.*;

public interface ButtonEditor2 {
    Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected);
}
