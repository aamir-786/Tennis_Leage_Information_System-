package ui;

import javax.swing.*;
import java.awt.*;

public interface ButtonRenderer1 {
    Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column);
}
