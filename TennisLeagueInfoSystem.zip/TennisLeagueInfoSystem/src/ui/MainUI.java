package ui;

import model.Coach;
import model.Player;
import model.Team;
import service.CoachService;
import service.PlayerService;
import service.TeamService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellEditor;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.List;

class ButtonRenderer extends JButton implements javax.swing.table.TableCellRenderer {
    public ButtonRenderer() {
        setOpaque(true);
    }

    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        setText((value == null) ? "" : value.toString());
        return this;
    }
}

abstract class ButtonEditor extends DefaultCellEditor {
    protected JButton button;
    protected String label;
    protected boolean isPushed;
    protected TeamService teamService;
    protected PlayerService playerService;
    protected CoachService coachService;
    protected JTable table;
    protected String itemType;
    protected String actionType;

    public ButtonEditor(JCheckBox checkBox, TeamService teamService, PlayerService playerService, CoachService coachService, JTable table, String itemType, String actionType) {
        super(checkBox);
        this.teamService = teamService;
        this.playerService = playerService;
        this.coachService = coachService;
        this.table = table;
        this.itemType = itemType;
        this.actionType = actionType;

        button = new JButton();
        button.setOpaque(true);
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                fireEditingStopped();
                int row = table.getSelectedRow();
                int id = (int) table.getValueAt(row, 0);
                if (actionType.equals("edit")) {
                    handleEditAction(id);
                } else if (actionType.equals("delete")) {
                    handleDeleteAction(id);
                }
            }
        });
    }

    private void handleEditAction(int id) {
        if (itemType.equals("team")) {
            handleTeamEdit(id);
        } else if (itemType.equals("player")) {
            handlePlayerEdit(id);
        } else if (itemType.equals("coach")) {
            handleCoachEdit(id);
        }
    }

    private void handleDeleteAction(int id) {
        if (itemType.equals("team")) {
            handleTeamDelete(id);
        } else if (itemType.equals("player")) {
            handlePlayerDelete(id);
        } else if (itemType.equals("coach")) {
            handleCoachDelete(id);
        }
    }

    private void handleTeamEdit(int id) {
        try {
            Team team = teamService.getTeamById(id);
            if (team != null) {
                // Show edit dialog
                JDialog dialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(button), "Edit Team", true);
                dialog.setSize(300, 200);
                dialog.setLayout(new GridLayout(4, 2));

                JLabel nameLabel = new JLabel("Team Name:");
                JTextField nameField = new JTextField(team.getName());
                JLabel coachIdLabel = new JLabel("Coach ID:");
                JTextField coachIdField = new JTextField(String.valueOf(team.getCoachId()));

                JButton saveButton = new JButton("Save");
                JButton cancelButton = new JButton("Cancel");

                dialog.add(nameLabel);
                dialog.add(nameField);
                dialog.add(coachIdLabel);
                dialog.add(coachIdField);
                dialog.add(saveButton);
                dialog.add(cancelButton);

                saveButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            String name = nameField.getText();
                            int coachId = Integer.parseInt(coachIdField.getText());

                            team.setName(name);
                            team.setCoachId(coachId);

                            teamService.updateTeam(team);
                            JOptionPane.showMessageDialog(dialog, "Team updated successfully!");
                            dialog.dispose();
                            ((DefaultTableModel) table.getModel()).setRowCount(0);
                            // Refresh the table data
                            refreshTable();
                        } catch (NumberFormatException ex) {
                            JOptionPane.showMessageDialog(dialog, "Invalid Coach ID.");
                        } catch (SQLException ex) {
                            JOptionPane.showMessageDialog(dialog, "Error updating team.");
                            ex.printStackTrace();
                        }
                    }
                });

                cancelButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        dialog.dispose();
                    }
                });

                dialog.setVisible(true);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error retrieving team.");
            ex.printStackTrace();
        }
    }

    private void handleTeamDelete(int id) {
        try {
            teamService.deleteTeam(id);
            JOptionPane.showMessageDialog(null, "Team deleted successfully!");
            ((DefaultTableModel) table.getModel()).setRowCount(0);
            refreshTable();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error deleting team.");
            ex.printStackTrace();
        }
    }

    private void handlePlayerEdit(int id) {
        try {
            Player player = playerService.getPlayerById(id);
            if (player != null) {
                // Show edit dialog
                JDialog dialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(button), "Edit Player", true);
                dialog.setSize(300, 200);
                dialog.setLayout(new GridLayout(4, 2));

                JLabel nameLabel = new JLabel("Player Name:");
                JTextField nameField = new JTextField(player.getName());
                JLabel teamIdLabel = new JLabel("Team ID:");
                JTextField teamIdField = new JTextField(String.valueOf(player.getTeamId()));

                JButton saveButton = new JButton("Save");
                JButton cancelButton = new JButton("Cancel");

                dialog.add(nameLabel);
                dialog.add(nameField);
                dialog.add(teamIdLabel);
                dialog.add(teamIdField);
                dialog.add(saveButton);
                dialog.add(cancelButton);

                saveButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            String name = nameField.getText();
                            int teamId = Integer.parseInt(teamIdField.getText());

                            player.setName(name);
                            player.setTeamId(teamId);

                            playerService.updatePlayer(player);
                            JOptionPane.showMessageDialog(dialog, "Player updated successfully!");
                            dialog.dispose();
                            ((DefaultTableModel) table.getModel()).setRowCount(0);
                            // Refresh the table data
                            refreshTable();
                        } catch (NumberFormatException ex) {
                            JOptionPane.showMessageDialog(dialog, "Invalid Team ID.");
                        } catch (SQLException ex) {
                            JOptionPane.showMessageDialog(dialog, "Error updating player.");
                            ex.printStackTrace();
                        }
                    }
                });

                cancelButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        dialog.dispose();
                    }
                });

                dialog.setVisible(true);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error retrieving player.");
            ex.printStackTrace();
        }
    }

    private void handlePlayerDelete(int id) {
        try {
            playerService.deletePlayer(id);
            JOptionPane.showMessageDialog(null, "Player deleted successfully!");
            ((DefaultTableModel) table.getModel()).setRowCount(0);
            refreshTable();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error deleting player.");
            ex.printStackTrace();
        }
    }

    private void handleCoachEdit(int id) {
        try {
            Coach coach = coachService.getCoachById(id);
            if (coach != null) {
                // Show edit dialog
                JDialog dialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(button), "Edit Coach", true);
                dialog.setSize(300, 200);
                dialog.setLayout(new GridLayout(4, 2));

                JLabel nameLabel = new JLabel("Coach Name:");
                JTextField nameField = new JTextField(coach.getName());
                JLabel teamIdLabel = new JLabel("Team ID:");
                JTextField teamIdField = new JTextField(String.valueOf(coach.getTeamId()));

                JButton saveButton = new JButton("Save");
                JButton cancelButton = new JButton("Cancel");

                dialog.add(nameLabel);
                dialog.add(nameField);
                dialog.add(teamIdLabel);
                dialog.add(teamIdField);
                dialog.add(saveButton);
                dialog.add(cancelButton);

                saveButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            String name = nameField.getText();
                            int teamId = Integer.parseInt(teamIdField.getText());

                            coach.setName(name);
                            coach.setTeamId(teamId);

                            coachService.updateCoach(coach);
                            JOptionPane.showMessageDialog(dialog, "Coach updated successfully!");
                            dialog.dispose();
                            ((DefaultTableModel) table.getModel()).setRowCount(0);
                            // Refresh the table data
                            refreshTable();
                        } catch (NumberFormatException ex) {
                            JOptionPane.showMessageDialog(dialog, "Invalid Team ID.");
                        } catch (SQLException ex) {
                            JOptionPane.showMessageDialog(dialog, "Error updating coach.");
                            ex.printStackTrace();
                        }
                    }
                });

                cancelButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        dialog.dispose();
                    }
                });

                dialog.setVisible(true);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error retrieving coach.");
            ex.printStackTrace();
        }
    }

    private void handleCoachDelete(int id) {
        try {
            coachService.deleteCoach(id);
            JOptionPane.showMessageDialog(null, "Coach deleted successfully!");
            ((DefaultTableModel) table.getModel()).setRowCount(0);
            refreshTable();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error deleting coach.");
            ex.printStackTrace();
        }
    }

    public abstract void refreshTable();

    @Override
    public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
        label = (value == null) ? "" : value.toString();
        button.setText(label);
        isPushed = true;
        return button;
    }

    @Override
    public Object getCellEditorValue() {
        if (isPushed) {
            // Actions handled in button action listener
        }
        isPushed = false;
        return label;
    }

    @Override
    public boolean stopCellEditing() {
        isPushed = false;
        return super.stopCellEditing();
    }

    @Override
    protected void fireEditingStopped() {
        super.fireEditingStopped();
    }
}

public class MainUI {
    private JFrame frame;
    private TeamService teamService;
    private PlayerService playerService;
    private CoachService coachService;

    public MainUI() throws SQLException {
        teamService = new TeamService();
        playerService = new PlayerService();
        coachService = new CoachService();

        frame = new JFrame("Tennis League Information System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);

        // Set background picture
        JLabel background = new JLabel(new ImageIcon("src/picture/img_6.png"));
        frame.setContentPane(background);
        frame.setLayout(new BorderLayout());

        // Welcome title
        JLabel welcomeLabel = new JLabel("Welcome to Tennis League Information System", JLabel.CENTER);
        welcomeLabel.setFont(new Font("Serif", Font.BOLD, 35));
        welcomeLabel.setForeground(Color.BLACK);
        frame.add(welcomeLabel, BorderLayout.NORTH);

        JPanel panel = new JPanel();
        panel.setOpaque(false);
        frame.add(panel, BorderLayout.PAGE_END);

        JButton addTeamsButton = new JButton("Add Teams");
        JButton viewTeamsButton = new JButton("View Teams");
        JButton addPlayersButton = new JButton("Add Players");
        JButton viewPlayersButton = new JButton("View Players");
        JButton addCoachesButton = new JButton("Add Coaches");
        JButton viewCoachesButton = new JButton("View Coaches");

        panel.add(addTeamsButton);
        panel.add(viewTeamsButton);
        panel.add(addPlayersButton);
        panel.add(viewPlayersButton);
        panel.add(addCoachesButton);
        panel.add(viewCoachesButton);

        addTeamsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showAddTeamDialog();
            }
        });

        addPlayersButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showAddPlayerDialog();
            }
        });

        addCoachesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showAddCoachDialog();
            }
        });

        viewTeamsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showViewTeamsDialog();
            }
        });

        viewPlayersButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showViewPlayersDialog();
            }
        });

        viewCoachesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showViewCoachesDialog();
            }
        });

        frame.setVisible(true);
    }

    private void showAddTeamDialog() {
        JDialog dialog = new JDialog(frame, "Add Team", true);
        dialog.setSize(300, 200);
        dialog.setLayout(new GridLayout(4, 2));

        JLabel nameLabel = new JLabel("Team Name:");
        JTextField nameField = new JTextField();
        JLabel coachIdLabel = new JLabel("Coach ID:");
        JTextField coachIdField = new JTextField();

        JButton saveButton = new JButton("Save");
        JButton cancelButton = new JButton("Cancel");

        dialog.add(nameLabel);
        dialog.add(nameField);
        dialog.add(coachIdLabel);
        dialog.add(coachIdField);
        dialog.add(saveButton);
        dialog.add(cancelButton);

        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String name = nameField.getText();
                    int coachId = Integer.parseInt(coachIdField.getText());

                    teamService.addTeam(new Team(0, name, coachId));
                    JOptionPane.showMessageDialog(dialog, "Team added successfully!");
                    dialog.dispose();
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(dialog, "Invalid Coach ID.");
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(dialog, "Error adding team.");
                    ex.printStackTrace();
                }
            }
        });

        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dialog.dispose();
            }
        });

        dialog.setVisible(true);
    }

    private void showAddPlayerDialog() {
        JDialog dialog = new JDialog(frame, "Add Player", true);
        dialog.setSize(300, 200);
        dialog.setLayout(new GridLayout(4, 2));

        JLabel nameLabel = new JLabel("Player Name:");
        JTextField nameField = new JTextField();
        JLabel teamIdLabel = new JLabel("Team ID:");
        JTextField teamIdField = new JTextField();

        JButton saveButton = new JButton("Save");
        JButton cancelButton = new JButton("Cancel");

        dialog.add(nameLabel);
        dialog.add(nameField);
        dialog.add(teamIdLabel);
        dialog.add(teamIdField);
        dialog.add(saveButton);
        dialog.add(cancelButton);

        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String name = nameField.getText();
                    int teamId = Integer.parseInt(teamIdField.getText());

                    playerService.addPlayer(new Player(0, name, teamId));
                    JOptionPane.showMessageDialog(dialog, "Player added successfully!");
                    dialog.dispose();
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(dialog, "Invalid Team ID.");
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(dialog, "Error adding player.");
                    ex.printStackTrace();
                }
            }
        });

        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dialog.dispose();
            }
        });

        dialog.setVisible(true);
    }

    private void showAddCoachDialog() {
        JDialog dialog = new JDialog(frame, "Add Coach", true);
        dialog.setSize(300, 200);
        dialog.setLayout(new GridLayout(4, 2));

        JLabel nameLabel = new JLabel("Coach Name:");
        JTextField nameField = new JTextField();
        JLabel teamIdLabel = new JLabel("Team ID:");
        JTextField teamIdField = new JTextField();

        JButton saveButton = new JButton("Save");
        JButton cancelButton = new JButton("Cancel");

        dialog.add(nameLabel);
        dialog.add(nameField);
        dialog.add(teamIdLabel);
        dialog.add(teamIdField);
        dialog.add(saveButton);
        dialog.add(cancelButton);

        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String name = nameField.getText();
                    int teamId = Integer.parseInt(teamIdField.getText());

                    coachService.addCoach(new Coach(0, name, teamId));
                    JOptionPane.showMessageDialog(dialog, "Coach added successfully!");
                    dialog.dispose();
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(dialog, "Invalid Team ID.");
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(dialog, "Error adding coach.");
                    ex.printStackTrace();
                }
            }
        });

        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dialog.dispose();
            }
        });

        dialog.setVisible(true);
    }

    private void showViewTeamsDialog() {
        try {
            List<Team> teams = teamService.getAllTeams();
            String[] columnNames = {"ID", "Name", "Coach ID", "Edit", "Delete"};
            DefaultTableModel model = new DefaultTableModel(columnNames, 0);
            for (Team team : teams) {
                model.addRow(new Object[]{team.getId(), team.getName(), team.getCoachId(), "Edit", "Delete"});
            }
            JTable table = new JTable(model);
            table.setRowHeight(30);
            table.getColumnModel().getColumn(3).setCellRenderer(new ButtonRenderer());
            table.getColumnModel().getColumn(3).setCellEditor(new ButtonEditor(new JCheckBox(), teamService, playerService, coachService, table, "team", "edit") {
                @Override
                public void refreshTable() {
                    showViewTeamsDialog();
                }
            });
            table.getColumnModel().getColumn(4).setCellRenderer(new ButtonRenderer());
            table.getColumnModel().getColumn(4).setCellEditor(new ButtonEditor(new JCheckBox(), teamService, playerService, coachService, table, "team", "delete") {
                @Override
                public void refreshTable() {
                    showViewTeamsDialog();
                }
            });

            JScrollPane scrollPane = new JScrollPane(table);
            JDialog dialog = new JDialog(frame, "View Teams", true);
            dialog.setSize(600, 400);
            dialog.add(scrollPane);
            dialog.setVisible(true);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error retrieving teams.");
            ex.printStackTrace();
        }
    }

    private void showViewPlayersDialog() {
        try {
            List<Player> players = playerService.getAllPlayers();
            String[] columnNames = {"ID", "Name", "Team ID", "Edit", "Delete"};
            DefaultTableModel model = new DefaultTableModel(columnNames, 0);
            for (Player player : players) {
                model.addRow(new Object[]{player.getId(), player.getName(), player.getTeamId(), "Edit", "Delete"});
            }
            JTable table = new JTable(model);
            table.setRowHeight(30);
            table.getColumnModel().getColumn(3).setCellRenderer(new ButtonRenderer());
            table.getColumnModel().getColumn(3).setCellEditor(new ButtonEditor(new JCheckBox(), teamService, playerService, coachService, table, "player", "edit") {
                @Override
                public void refreshTable() {
                    showViewPlayersDialog();
                }
            });
            table.getColumnModel().getColumn(4).setCellRenderer(new ButtonRenderer());
            table.getColumnModel().getColumn(4).setCellEditor(new ButtonEditor(new JCheckBox(), teamService, playerService, coachService, table, "player", "delete") {
                @Override
                public void refreshTable() {
                    showViewPlayersDialog();
                }
            });

            JScrollPane scrollPane = new JScrollPane(table);
            JDialog dialog = new JDialog(frame, "View Players", true);
            dialog.setSize(600, 400);
            dialog.add(scrollPane);
            dialog.setVisible(true);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error retrieving players.");
            ex.printStackTrace();
        }
    }

    private void showViewCoachesDialog() {
        try {
            List<Coach> coaches = coachService.getAllCoaches();
            String[] columnNames = {"ID", "Name", "Team ID", "Edit", "Delete"};
            DefaultTableModel model = new DefaultTableModel(columnNames, 0);
            for (Coach coach : coaches) {
                model.addRow(new Object[]{coach.getId(), coach.getName(), coach.getTeamId(), "Edit", "Delete"});
            }
            JTable table = new JTable(model);
            table.setRowHeight(30);
            table.getColumnModel().getColumn(3).setCellRenderer(new ButtonRenderer());
            table.getColumnModel().getColumn(3).setCellEditor(new ButtonEditor(new JCheckBox(), teamService, playerService, coachService, table, "coach", "edit") {
                @Override
                public void refreshTable() {
                    showViewCoachesDialog();
                }
            });
            table.getColumnModel().getColumn(4).setCellRenderer(new ButtonRenderer());
            table.getColumnModel().getColumn(4).setCellEditor(new ButtonEditor(new JCheckBox(), teamService, playerService, coachService, table, "coach", "delete") {
                @Override
                public void refreshTable() {
                    showViewCoachesDialog();
                }
            });

            JScrollPane scrollPane = new JScrollPane(table);
            JDialog dialog = new JDialog(frame, "View Coaches", true);
            dialog.setSize(600, 400);
            dialog.add(scrollPane);
            dialog.setVisible(true);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error retrieving coaches.");
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) throws SQLException {
        new MainUI();
    }
}
